from PortMap24 import * 
#8,0
driveBase.settings(straight_speed=90)
driveBase.straight(350)
driveBase.straight(300)
driveBase.straight(-100)
driveBase.turn(60)
driveBase.straight(300)
#driveBase.turn(30)
#driveBase.straight(250)
driveBase.turn(-16)
driveBase.straight(350)
driveBase.turn(45)
driveBase.straight(180)
motorFront.run_angle(100,360)



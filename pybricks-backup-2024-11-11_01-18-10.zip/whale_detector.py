from PortMap24 import *

driveBase.straight(650)
driveBase.turn(-90)
driveBase.straight(100)
driveBase.turn(90)
driveBase.straight(80)
motorFront.run_angle(200, -330)
driveBase.straight(-200)

motorFront.run_angle(200, 30)
driveBase.turn(45)
driveBase.straight(100)
driveBase.turn(-80)
driveBase.straight(-80)
driveBase.turn(5)
#motorFront.run_angle(200, 35)
driveBase.straight(150)

motorFront.run_angle(200, 300)
